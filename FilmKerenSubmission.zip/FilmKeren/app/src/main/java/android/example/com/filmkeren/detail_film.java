package android.example.com.filmkeren;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class detail_film extends AppCompatActivity {

    public static final String EXTRA_FILM = "extra_film";


    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_film);


        TextView tvNameFilm = findViewById(R.id.tv_object_received);
        ImageView imgDetailFilm = findViewById(R.id.img_film_photo);
        TextView tvFilmContent = findViewById(R.id.film_description);


        Film film = getIntent().getParcelableExtra(EXTRA_FILM);

        String text = film.getName();
        tvNameFilm.setText(text);

        tvFilmContent.setText(film.getDescription());
        imgDetailFilm.setImageResource(film.getPhoto());

        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setTitle(film.getName());
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
}
